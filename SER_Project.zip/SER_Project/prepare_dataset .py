import os
import shutil
from sklearn.model_selection import train_test_split
import glob

# Emotion mapping from RAVDESS filename (ZZ part)
EMOTION_MAP = {
    '01': 'neutral',
    '02': 'calm',
    '03': 'happy',
    '04': 'sad',
    '05': 'angry',
    '06': 'fearful',
    '07': 'disgust',
    '08': 'surprised'
}

def prepare_ravdess(raw_dir='data', train_dir='data/train/', test_dir='data/test/'):
    """
    Extracts .wav files from RAVDESS (actors 01-24), labels by emotion, splits 80/20, and organizes into folders.
    """
    raw_dir = os.path.normpath(raw_dir)
    print(f"Searching for files in: {os.path.abspath(raw_dir)}")
    
    # Create output dirs
    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(test_dir, exist_ok=True)
    
    all_files = []
    
    # Find all .wav files
    actor_dirs = sorted(glob.glob(os.path.join(raw_dir, "Actor_*")))
    if not actor_dirs:
        print(f"Error: No Actor_* folders found in {raw_dir}. Contents: {os.listdir(raw_dir)}")
        return
    
    print(f"Found {len(actor_dirs)} actor folders: {[os.path.basename(d) for d in actor_dirs]}")
    
    for actor_dir in actor_dirs:
        wav_files = glob.glob(os.path.join(actor_dir, "*.wav"))
        print(f"Checking {os.path.basename(actor_dir)}: found {len(wav_files)} .wav files")
        for file in wav_files:
            filename = os.path.basename(file)
            parts = filename.split('-')
            if len(parts) >= 3 and parts[0] == '03' and parts[1] == '01':
                emotion_code = parts[2]
                if emotion_code in EMOTION_MAP:
                    emotion = EMOTION_MAP[emotion_code]
                    all_files.append((file, emotion))
                else:
                    print(f"Skipping {filename}: invalid emotion code {emotion_code}")
            else:
                print(f"Skipping {filename}: not a speech file (expected 03-01-...)")
    
    print(f"Found {len(all_files)} valid speech files across {len(EMOTION_MAP)} emotions.")
    if not all_files:
        print("Error: No valid files found. Check if files match '03-01-XX-...' format.")
        return
    
    # Split per emotion
    train_files = []
    test_files = []
    for emotion in EMOTION_MAP.values():
        emotion_files = [(f, e) for f, e in all_files if e == emotion]
        print(f"Emotion {emotion}: {len(emotion_files)} files")
        if not emotion_files:
            print(f"Warning: No files for emotion {emotion}")
            continue
        train_em, test_em = train_test_split(emotion_files, test_size=0.2, random_state=42)
        train_files.extend(train_em)
        test_files.extend(test_em)
    
    print(f"Train set: {len(train_files)} files, Test set: {len(test_files)} files")
    
    # Copy to folders
    for file_path, emotion in train_files:
        dest_dir = os.path.join(train_dir, emotion)
        os.makedirs(dest_dir, exist_ok=True)
        shutil.copy(file_path, os.path.join(dest_dir, os.path.basename(file_path)))
    
    for file_path, emotion in test_files:
        dest_dir = os.path.join(test_dir, emotion)
        os.makedirs(dest_dir, exist_ok=True)
        shutil.copy(file_path, os.path.join(dest_dir, os.path.basename(file_path)))
    
    print("Dataset prepared! Folders created: data/train/, data/test/")
    print(f"Train folders: {os.listdir(train_dir)}")
    print(f"Test folders: {os.listdir(test_dir)}")

if __name__ == "__main__":
    prepare_ravdess()