import os
from datasets import load_dataset, Audio, ClassLabel
from transformers import AutoFeatureExtractor, AutoModelForAudioClassification, TrainingArguments, Trainer
import evaluate
import numpy as np
import torch

# RAVDESS emotions (8 classes)
emotions = ["neutral", "calm", "happy", "sad", "angry", "fearful", "disgust", "surprised"]
num_labels = len(emotions)
label2id = {label: i for i, label in enumerate(emotions)}
id2label = {i: label for label, i in label2id.items()}

# Step 1: Load dataset
dataset = load_dataset("audiofolder", data_dir="data")

# Cast columns
dataset = dataset.cast_column("audio", Audio(sampling_rate=16000))
dataset = dataset.cast_column("label", ClassLabel(num_classes=num_labels, names=emotions))

# Step 2: Preprocess
feature_extractor = AutoFeatureExtractor.from_pretrained("superb/hubert-base-superb-er")

def preprocess_function(examples):
    audio_arrays = [x["array"] for x in examples["audio"]]
    inputs = feature_extractor(
        audio_arrays, 
        sampling_rate=16000, 
        return_tensors="pt", 
        padding=True,
        truncation=True,
        max_length=16000 * 4
    )
    inputs["labels"] = examples["label"]
    return inputs

encoded_dataset = dataset.map(preprocess_function, remove_columns=dataset["train"].column_names, batched=True)

# Step 3: Load model
model = AutoModelForAudioClassification.from_pretrained(
    "superb/hubert-base-superb-er",
    num_labels=num_labels,
    label2id=label2id,
    id2label=id2label,
    ignore_mismatched_sizes=True
)

# Step 4: Metrics and training args
metric = evaluate.load("accuracy")

def compute_metrics(eval_pred):
    predictions, label_ids = eval_pred
    print(f"Predictions type: {type(predictions)}, Labels type: {type(label_ids)}")
    if isinstance(predictions, tuple):
        print(f"Predictions tuple length: {len(predictions)}")
        print(f"Predictions tuple contents: {[type(p) for p in predictions]}")
        predictions = predictions[0]  # Take logits
    # Convert to NumPy if torch.Tensor
    if isinstance(predictions, torch.Tensor):
        predictions = predictions.cpu().numpy()
    if isinstance(label_ids, torch.Tensor):
        label_ids = label_ids.cpu().numpy()
    print(f"Predictions shape after handling: {predictions.shape}, Labels shape: {label_ids.shape}")
    # Ensure predictions has shape (batch_size, num_labels)
    if len(predictions.shape) != 2 or predictions.shape[1] != num_labels:
        raise ValueError(f"Expected predictions shape (batch_size, {num_labels}), got {predictions.shape}")
    predictions = np.argmax(predictions, axis=1)
    return metric.compute(predictions=predictions, references=label_ids)

training_args = TrainingArguments(
    output_dir="./finetuned_ser_ravdess",
    eval_strategy="epoch",
    save_strategy="epoch",
    learning_rate=3e-5,
    per_device_train_batch_size=2,
    per_device_eval_batch_size=2,
    num_train_epochs=3,
    weight_decay=0.01,
    load_best_model_at_end=True,
    metric_for_best_model="accuracy",
    greater_is_better=True,
    report_to="none"
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=encoded_dataset["train"],
    eval_dataset=encoded_dataset["test"],
    tokenizer=feature_extractor,
    compute_metrics=compute_metrics
)

# Step 5: Train
print("Starting training on RAVDESS (Actors 01-24)...")
trainer.train()

# Step 6: Save
trainer.save_model("./finetuned_ser_ravdess")
feature_extractor.save_pretrained("./finetuned_ser_ravdess")
print("Training complete! Model saved to './finetuned_ser_ravdess'.")