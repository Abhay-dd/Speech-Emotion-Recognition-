import soundfile as sf
import numpy as np
from transformers import AutoFeatureExtractor, AutoModelForAudioClassification
import torch
import speech_recognition as sr

# Load model and feature extractor
model_path = "./finetuned_ser_ravdess"
feature_extractor = AutoFeatureExtractor.from_pretrained(model_path)
model = AutoModelForAudioClassification.from_pretrained(model_path)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
model.eval()

# Emotion labels
id2label = model.config.id2label

# Preprocess audio
def preprocess_audio(audio, sample_rate=16000):
    inputs = feature_extractor(
        audio,
        sampling_rate=sample_rate,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=16000 * 4
    )
    return {k: v.to(device) for k, v in inputs.items()}

# Predict emotion
def predict_emotion(audio, sample_rate=16000):
    inputs = preprocess_audio(audio, sample_rate)
    with torch.no_grad():
        outputs = model(**inputs)
    logits = outputs.logits
    predicted_id = torch.argmax(logits, dim=1).item()
    return id2label[predicted_id]

# Speech-to-text
def speech_to_text(audio_file):
    recognizer = sr.Recognizer()
    try:
        with sr.AudioFile(audio_file) as source:
            audio = recognizer.record(source)
        text = recognizer.recognize_google(audio)
        return text
    except sr.UnknownValueError:
        return "Could not understand audio."
    except sr.RequestError:
        return "Speech recognition service unavailable."
    except Exception as e:
        return f"Error in speech recognition: {str(e)}"

# Example usage (can be modified based on input method)
if __name__ == "__main__":
    # Example: Process a local WAV file
    audio_file_path = "temp_audio.wav"  # Replace with your WAV file path
    if audio_file_path:
        audio_data, sample_rate = sf.read(audio_file_path)
        emotion = predict_emotion(audio_data, sample_rate)
        text = speech_to_text(audio_file_path)
        
        # Generate response based on emotion
        response = ""
        if emotion in ["happy", "surprised"]:
            response = "You sound excited! What's got you in such a great mood?"
        elif emotion in ["sad", "fearful"]:
            response = "You seem a bit down or worried. Want to talk about it?"
        elif emotion in ["angry", "disgust"]:
            response = "Sounds like something's upsetting you. What's going on?"
        else:
            response = "You sound pretty calm. What's on your mind today?"
        
        print(f"Detected Emotion: {emotion}")
        print(f"Transcribed Text: {text}")
        print(f"Chatbot Response: {response}")
    else:
        print("Please provide a valid WAV file path.")